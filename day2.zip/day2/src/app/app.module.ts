import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AngularBasicsComponent } from './angular-basics/angular-basics.component';
import { AngularPipesComponent } from './angular-pipes/angular-pipes.component';
import { TechnologiesComponent } from './technologies/technologies.component';
import { HomeComponent } from './home/home.component';

@NgModule({
  declarations: [  //components,directives,pipes
    AppComponent, AngularBasicsComponent, AngularPipesComponent, TechnologiesComponent, HomeComponent
  ],
  imports: [ //modules
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],//services
  //bootstrap: [AppComponent,AngularBasicsComponent,AngularPipesComponent,TechnologiesComponent]//components
  bootstrap: [AppComponent]//components

})
export class AppModule { }
