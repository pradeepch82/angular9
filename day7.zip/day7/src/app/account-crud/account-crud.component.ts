import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-account-crud',
  templateUrl: './account-crud.component.html',
  styleUrls: ['./account-crud.component.css']
})
export class AccountCRUDComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
