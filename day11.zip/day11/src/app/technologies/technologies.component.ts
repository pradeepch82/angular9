import { Component, OnInit, OnDestroy } from '@angular/core';

@Component({
  selector: 'app-technologies',
  templateUrl: './technologies.component.html',
  styleUrls: ['./technologies.component.css']
})
export class TechnologiesComponent implements OnInit,OnDestroy {

  title="Top 5 technologies";   //string

  technologies=[
    {id:1,name:'Angular',likes:0,dislikes:0},
    {id:2,name:'Micro Sevrvices',likes:0,dislikes:0},
    {id:3,name:'Spring Boot',likes:0,dislikes:0},
    {id:4,name:'Python',likes:0,dislikes:0},
    {id:5,name:'Machine Laearning',likes:0,dislikes:0},
   ];  //array



   incrmentLikes(t){
     t.likes++;
   }

   incrmentDislikes(t){
     t.dislikes++;
   }



  constructor() { 
    console.log("############ TechnologiesComponent  created #############");

  }

  ngOnInit(): void {
    console.log("############ TechnologiesComponent  initialized #############");
    
  }

  ngOnDestroy(): void {
    console.log("############ TechnologiesComponent  destroyed #############");
    }

}
