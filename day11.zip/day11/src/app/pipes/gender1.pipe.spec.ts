import { Gender1Pipe } from './gender1.pipe';

describe('Gender1Pipe', () => {
  it('create an instance', () => {
    const pipe = new Gender1Pipe();
    expect(pipe).toBeTruthy();
  });
});
