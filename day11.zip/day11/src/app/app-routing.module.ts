import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AngularBasicsComponent } from './angular-basics/angular-basics.component';
import { AngularPipesComponent } from './angular-pipes/angular-pipes.component';
import { TechnologiesComponent } from './technologies/technologies.component';
import { HomeComponent } from './home/home.component';
import { CaseStudyComponent } from './case-study/case-study.component';
import { UsersComponent } from './users/users.component';
import { PostsComponent } from './posts/posts.component';
import { TodosComponent } from './todos/todos.component';
import { PhotosComponent } from './photos/photos.component';
import { CommentsComponent } from './comments/comments.component';
import { AlbumsComponent } from './albums/albums.component';
import { UsersListComponent } from './users-list/users-list.component';
import { UsersTableComponent } from './users-table/users-table.component';
import { AccountCRUDComponent } from './account-crud/account-crud.component';
import { NestedComponent } from './nested/nested.component';
import { CustomDirectivesComponent } from './custom-directives/custom-directives.component';
import { ViewChildComponent } from './view-child/view-child.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { MultiGuard } from './guards/multi.guard';
import { PreloadAllModules } from '@angular/router';

const routes: Routes = [
  {path:'basics',component:AngularBasicsComponent,canActivate:[MultiGuard]},
  {path:'pipes',component:AngularPipesComponent,canActivate:[MultiGuard]},
  {path:'technologies',component:TechnologiesComponent,canActivate:[MultiGuard]},
  {path:'casestudy',component:CaseStudyComponent,
  canActivate:[MultiGuard],
  canActivateChild:[MultiGuard],
   children:[
    {path:'users',component:UsersComponent,
    children:[
      {path:'list',component:UsersListComponent},
      {path:'table',component:UsersTableComponent},
     ]
    },
    {path:'users/:user_id',component:UsersComponent},
    {path:'posts',component:PostsComponent},
    {path:'comments',component:CommentsComponent},
    {path:'todos',component:TodosComponent},
    {path:'photos',component:PhotosComponent},
    {path:'albums',component:AlbumsComponent},
     
   ]

},
{path:'account-crud',component:AccountCRUDComponent,canActivate:[MultiGuard]},
{path:'nested-comp',component:NestedComponent,canActivate:[MultiGuard],canDeactivate:[MultiGuard]},
{path:'custom-directives',component:CustomDirectivesComponent,canActivate:[MultiGuard],canDeactivate:[MultiGuard]},
{path:'view-child',component:ViewChildComponent,canActivate:[MultiGuard]},
{path:'login',component:LoginComponent},
{path:'register',component:RegisterComponent},
{path:'home',component:HomeComponent,canActivate:[MultiGuard]},
{path:'address',loadChildren:'app/address/address.module#AddressModule',canLoad:[MultiGuard]},
{path:'**',component:HomeComponent},

   
];

@NgModule({
  imports: [RouterModule.forRoot(routes,{preloadingStrategy: PreloadAllModules})],
  exports: [RouterModule]
})
export class AppRoutingModule {

  constructor(){
    console.log("@@@@@@@@@@@@@@@@ AppRoutingModule @@@@@@@@@@@@@@@@@@@@@@");
  }

 }
