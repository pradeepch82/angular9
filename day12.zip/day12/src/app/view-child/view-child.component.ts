import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { NumberComponent } from '../number/number.component';
import { FgColorDirective } from '../directives/fg-color.directive';

@Component({
  selector: 'app-view-child',
  templateUrl: './view-child.component.html',
  styleUrls: ['./view-child.component.css']
})
export class ViewChildComponent implements OnInit {


  
  @ViewChild(NumberComponent,{static:false})
  private n:NumberComponent;

  @ViewChild(FgColorDirective,{static:false})
  private f:FgColorDirective;

  @ViewChild("name",{static:false})
  private name:ElementRef;
  
  @ViewChild("city",{static:false})
  private city:ElementRef;
  
  
  constructor() { }

  ngOnInit(): void {

  }

  increaseNumber(){
     this.n.increase();
  }

 decreaseNumber(){
  this.n.decrease();
}

changeColor(){
   this.f.fgColor='magenta';
}

changeColors(){
  this.name.nativeElement.style.color="red";
  this.name.nativeElement.style.backgroundColor="cyan";

  this.city.nativeElement.style.color="brown";
  this.city.nativeElement.style.backgroundColor="yellow";
  

}





}
