import { Component, OnInit, Input,EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {

  message="Hello I am Child";


  @Input()
  parentMessage="";



  @Output()
  childChanged=new EventEmitter<string>();


  constructor() { 
    console.log("############ ChildComponent  created #############");

  }

  ngOnInit(): void {
    console.log("############ ChildComponent  initialized #############");
    
  }

  ngOnDestroy(): void {
    console.log("############ ChildComponent  destroyed #############");
    }

   sendMessageToParent(){
     console.log("in sendtoParentMessage"+this.message);
     this.childChanged.emit(this.message);
   }

  }
