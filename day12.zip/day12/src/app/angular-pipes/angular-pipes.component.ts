import { Component, OnInit } from '@angular/core';
import { Observable, Subscriber } from 'rxjs';

@Component({
  selector: 'app-angular-pipes',
  templateUrl: './angular-pipes.component.html',
  styleUrls: ['./angular-pipes.component.css']
})
export class AngularPipesComponent implements OnInit {

 title="Angular Pipes";

 employees=[
  { "id": 555, "name": "Ramesh chinchole", "salary": 124404, "variable": 0.15, "doj": "2021-02-22T01:27:01.230Z", "gender": 1, "city": "Mumbai", "pan": "amxpc9834D", "mobile": "7858652627" },
  { "id": 101, "name": "Ameya @/ raut", "salary": 334404.45677444, "variable": 0.15, "doj": "2022-02-22T01:27:01.230Z", "gender": 1, "city": "Pune", "pan": "amxpc9834E", "mobile": "8158652627" },
  { "id": 343, "name": "Pradeep kolhe", "salary": 3324404.45677444, "variable": 0.15, "doj": "2020-12-22T01:27:01.230Z", "gender": 1, "city": "Pune", "pan": "rtxpc9834G", "mobile": "9158652627" },
  { "id": 563, "name": "Delip sharma", "salary": 674404.45677444, "variable": 0.15, "doj": "1999-02-22T01:27:01.230Z", "gender": 3, "city": "Solapur", "pan": "amxpc9834D", "mobile": "8158652627" },
  { "id": 233, "name": "Pradeep chinchole", "salary": 24404.45677444, "variable": 0.15, "doj": "2020-02-22T01:27:01.230Z", "gender": 3, "city": "Kolhapur", "pan": "yyxpc9834T", "mobile": "8158652627" },
  { "id": 222, "name": "Prachitee chinchole", "salary": 2674404.45677444, "variable": 0.15, "doj": "2018-02-22T01:27:01.230Z", "gender": 2, "city": "Pune", "pan": "hhxpc9834U", "mobile": "7158652627" },
  { "id": 122, "name": "Vrushali patil", "salary": 488404.45677444, "variable": 0.15, "doj": "2021-02-22T01:27:01.230Z", "gender": 2, "city": "Banglore", "pan": "ddxpc9834M", "mobile": "6158652627" },
  ];

  rows=2;

  descending=false;


  sortColumn="id";

  searchText="" ;

   time=new Observable<string>((s:Subscriber<string>)=>{
     setInterval(()=>{
      s.next(new Date().toLocaleString());
      },1000);
  });


  sort(column){

    if(this.sortColumn==column)
    this.descending=!this.descending;

    this.sortColumn=column;
  }



  constructor() { 
    console.log("############ AngularPipesComponent  created #############");

  }

  ngOnInit(): void {
    console.log("############ AngularPipesComponent  initialized #############");
    
  }

  ngOnDestroy(): void {
    console.log("############ AngularPipesComponent  destroyed #############");
    }

  
    ngOnChanges() {
      console.log("############ AngularPipesComponent  ngOnChanges #############");
    }
    
    ngAfterContentInit() {
      console.log("############ AngularPipesComponent  ngAfterContentInit #############");
    }
    

    
    ngDoCheck() {
      console.log("############ AngularPipesComponent  ngDoCheck #############");
    }
    ngAfterContentChecked() {
      console.log("############ AngularPipesComponent  ngAfterContentChecked #############");
    }
    
    ngAfterViewChecked() {
      console.log("############ AngularPipesComponent  ngAfterViewChecked #############");
    }
    
    ngAfterViewInit() {
      console.log("############ AngularPipesComponent  ngAfterViewInit #############");
    }
  




}
