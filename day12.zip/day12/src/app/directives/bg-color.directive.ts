import { Directive, ElementRef, Renderer2, Input } from '@angular/core';

@Directive({
  selector: '[bgColor]'
})
export class BgColorDirective {

  constructor(private el:ElementRef ,private r:Renderer2) { 
    console.log(" FgColorDirective   created...")
  }


  @Input()
  set bgColor(value:string){
    console.log("In setBgColor :"+value);
    this.r.setStyle(this.el.nativeElement,"background-color",value); 
  }


}
