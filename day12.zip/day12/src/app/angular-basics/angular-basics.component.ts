import { Component, OnInit } from '@angular/core';
import { Observable, Subscriber } from 'rxjs';

@Component({
  selector: 'app-angular-basics',
  templateUrl: './angular-basics.component.html',
  styleUrls: ['./angular-basics.component.css']
})
export class AngularBasicsComponent {

  // variable_name:dataype=value;

  title="Angular Basics"; //string

  colors=["red","green","blue","orange","magenta"]; //array

  day=1;//number

  min:number=1;//number

  max:number=8;

  show:boolean=true; //boolean

  hide=false; //boolean

  employee={id:101,
            name:'Pradeep chinchole',
            salary:124404.45677444,
            variable:0.15,
            doj:new Date(),
            gender:1,
            city:'Pune',
            pan:'amxpc9834D',
            mobile:'9158652627'}; //JS object
          


            time=new Observable<string>((s:Subscriber<string>)=>{
              setInterval(()=>{
               s.next(new Date().toLocaleString());
               },1000);
           });


 

            constructor() { 
              console.log("############ AngularBasicsComponent  created #############");
          
            }
          
            ngOnInit(): void {
              console.log("############ AngularBasicsComponent  initialized #############");
              
            }
          
            ngOnDestroy(): void {
              console.log("############ AngularBasicsComponent  destroyed #############");
              }
          
            
            
              ngDoCheck() {
                console.log("############ AngularBasicsComponent  ngDoCheck #############");
              }

              
              ngOnChanges() {
                console.log("############ AngularBasicsComponent  ngOnChanges #############");
              }
              
              ngAfterContentInit() {
                console.log("############ AngularBasicsComponent  ngAfterContentInit #############");
              }
              
              ngAfterContentChecked() {
                console.log("############ AngularBasicsComponent  ngAfterContentChecked #############");
              }
              
              ngAfterViewChecked() {
                console.log("############ AngularBasicsComponent  ngAfterViewChecked #############");
              }
              
              ngAfterViewInit() {
                console.log("############ AngularBasicsComponent  ngAfterViewInit #############");
              }
            
          
          
          

    showHide(){
      this.hide=!this.hide;
    }


}
