import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import {HttpClientModule} from "@angular/common/http";



import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AngularBasicsComponent } from './angular-basics/angular-basics.component';
import { AngularPipesComponent } from './angular-pipes/angular-pipes.component';
import { TechnologiesComponent } from './technologies/technologies.component';
import { HomeComponent } from './home/home.component';
import { GenderPipe } from './pipes/gender.pipe';
import { OrderByPipe } from './pipes/order-by.pipe';
import { Gender1Pipe } from './pipes/gender1.pipe';
import { UsersComponent } from './users/users.component';
import { PostsComponent } from './posts/posts.component';
import { CommentsComponent } from './comments/comments.component';
import { TodosComponent } from './todos/todos.component';
import { AlbumsComponent } from './albums/albums.component';
import { PhotosComponent } from './photos/photos.component';
import { CaseStudyComponent } from './case-study/case-study.component';
import { UsersListComponent } from './users-list/users-list.component';
import { UsersTableComponent } from './users-table/users-table.component';
import { PostsService } from './services/posts.service';
import { RouterModule } from '@angular/router';
import { NestedComponent } from './nested/nested.component';
import { CustomDirectivesComponent } from './custom-directives/custom-directives.component';
import { ViewChildComponent } from './view-child/view-child.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { AccountCRUDComponent } from './account-crud/account-crud.component';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';
import { FgColorDirective } from './directives/fg-color.directive';
import { BgColorDirective } from './directives/bg-color.directive';
import { ShowDirective } from './directives/show.directive';
import { HideDirective } from './directives/hide.directive';
import { CountryComponent } from './country/country.component';
import { StateComponent } from './state/state.component';
import { CityComponent } from './city/city.component';
import { NumberComponent } from './number/number.component';
import { ReactiveFormsModule } from '@angular/forms';
import { MustMatchDirective } from './must-match.directive';


@NgModule({
  declarations: [  //components,directives,pipes
    AppComponent, AngularBasicsComponent, AngularPipesComponent, 
    TechnologiesComponent, HomeComponent, GenderPipe, OrderByPipe, Gender1Pipe, UsersComponent,
     PostsComponent, CommentsComponent, TodosComponent, AlbumsComponent, PhotosComponent, 
     CaseStudyComponent, UsersListComponent, UsersTableComponent, NestedComponent,
      CustomDirectivesComponent, ViewChildComponent, LoginComponent, RegisterComponent,
       AccountCRUDComponent, ParentComponent, ChildComponent, FgColorDirective,
        BgColorDirective, ShowDirective, HideDirective, CountryComponent,
         StateComponent, CityComponent, NumberComponent, MustMatchDirective
  ],
  imports: [ //modules
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    Ng2SearchPipeModule,
HttpClientModule,
ReactiveFormsModule,

  ],
  providers: [PostsService],//services
  //bootstrap: [AppComponent,AngularBasicsComponent,AngularPipesComponent,TechnologiesComponent]//components
  bootstrap: [AppComponent]//components

})
export class AppModule { }
