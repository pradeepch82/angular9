import { Component, OnInit, Input, Output ,EventEmitter} from '@angular/core';


@Component({
  selector: 'app-state',
  templateUrl: './state.component.html',
  styleUrls: ['./state.component.css']
})
export class StateComponent implements OnInit {

   name="Maharashtra";

   @Input()
   countryName="";
   
   cityName="";
   


   @Output()
  cityChanged=new EventEmitter<string>();
 
  @Output()
  stateChanged=new EventEmitter<string>();


  sendStateToCountry(){
    this.stateChanged.emit(this.name);
    console.log("sendCityTo State  :"+this.name);
  }




 
  constructor() {
    console.log("===========StateComponent created===============");
   }
  
  ngOnInit() {
    console.log("===========StateComponent initialized===============");
    
  }
  
  ngOnDestroy() {
    console.log("===========StateComponent destroyed===============");
  }
  
  ngOnChanges() {
    console.log("===========StateComponent ngOnChanges===============");
  }
  
  ngAfterContentInit() {
    console.log("===========StateComponent ngAfterContentInit===============");
  }
  
  ngAfterContentChecked() {
    console.log("===========StateComponent ngAfterContentChecked===============");
  }
  
  ngAfterViewChecked() {
    console.log("===========StateComponent ngAfterViewChecked===============");
  }
  
  ngAfterViewInit() {
    console.log("===========StateComponent ngAfterViewInit===============");
  }

  setCity(value){
     this.cityName=value;
     this.cityChanged.emit(this.cityName)
  }
}
