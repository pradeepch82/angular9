import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nested',
  templateUrl: './nested.component.html',
  styleUrls: ['./nested.component.css']
})
export class NestedComponent implements OnInit {

  
  constructor() { 
    console.log("############ NestedComponent  created #############");

  }

  ngOnInit(): void {
    console.log("############ NestedComponent  initialized #############");
    
  }

  ngOnDestroy(): void {
    console.log("############ NestedComponent  destroyed #############");
    }

  
  
    ngDoCheck() {
      console.log("############ NestedComponent  ngDoCheck #############");
    }

    
    ngOnChanges() {
      console.log("############ NestedComponent  ngOnChanges #############");
    }
    
    ngAfterContentInit() {
      console.log("############ NestedComponent  ngAfterContentInit #############");
    }
    
    ngAfterContentChecked() {
      console.log("############ NestedComponent  ngAfterContentChecked #############");
    }
    
    ngAfterViewChecked() {
      console.log("############ NestedComponent  ngAfterViewChecked #############");
    }
    
    ngAfterViewInit() {
      console.log("############ NestedComponent  ngAfterViewInit #############");
    }
  







}
