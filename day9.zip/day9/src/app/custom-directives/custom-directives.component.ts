import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-custom-directives',
  templateUrl: './custom-directives.component.html',
  styleUrls: ['./custom-directives.component.css']
})
export class CustomDirectivesComponent implements OnInit {

  title="Custome Directives";


  fcolor="red";

  bcolor="cyan";

  show=true;

  hide=false;


  constructor() { 
    console.log("############ CustomDirectivesComponent  created #############");

  }

  ngOnInit(): void {
    console.log("############ CustomDirectivesComponent  initialized #############");
    
  }

  ngOnDestroy(): void {
    console.log("############ CustomDirectivesComponent  destroyed #############");
    }


}
