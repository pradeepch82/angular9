import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-account-crud',
  templateUrl: './account-crud.component.html',
  styleUrls: ['./account-crud.component.css']
})
export class AccountCRUDComponent implements OnInit {

title="Angular Crud Demo";

customer:any;



customerId=0;

  customers=[
    {id:101,name:'Pradeep Chinchole',email:'pradeep@gmail.com'},
    {id:102,name:'Ramesh Patil',email:'Ramesh@gmail.com'},
    {id:103,name:'Sunil Kumar',email:'Sunil@gmail.com'},
   ];


  products=[
    {id:101,name:"",price:0.0},
    {id:101,name:"",price:0.0},
    {id:101,name:"",price:0.0},
    {id:101,name:"",price:0.0},
   ];



  constructor() { 
    console.log("############ AccountCRUDComponent  created #############");

  }

  ngOnInit(): void {
    console.log("############ AccountCRUDComponent  initialized #############");
    
  }

  ngOnDestroy(): void {
    console.log("############ AccountCRUDComponent  destroyed #############");
    }


  newCustomer(){
     this.customer= {id:0,name:'',email:''};
  }

  editCustomer(id:number){

    this.customer=this.customers.filter((c,index)=>c.id==id)[0]
    this.customerId=this.customer.id;    

  }
  deleteCustomer(id:number){

   this.customers=this.customers.filter((c,index)=>c.id!=id);

   //this.customers=this.customers.filter(function (c,index){return c.id!=id;})


  }

  addCustomer(){
   this.customers.push(this.customer);
   this.customer=null;
  }

 updateCustomer(){
  
  this.customers.forEach((c,index)=>{
  if(this.customerId==c.id)
   this.customers[index]=this.customer;
  });

  }









}
