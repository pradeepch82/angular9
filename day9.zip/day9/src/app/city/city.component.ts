import { Component, OnInit, Input,EventEmitter, Output } from '@angular/core';


@Component({
  selector: 'app-city',
  templateUrl: './city.component.html',
  styleUrls: ['./city.component.css']
})
export class CityComponent implements OnInit {

  name="Pune";

  @Input()
  countryName="";

  @Input()
  stateName="";


  @Output()
  cityChanged=new EventEmitter<string>();


  sendCityToState(){
    this.cityChanged.emit(this.name);
    console.log("sendCityTo State  :"+this.name);
  }


  constructor() {
    console.log("===========CityComponent created===============");
   }
  
  ngOnInit() {
    console.log("===========CityComponent initialized===============");
    
  }
  
  ngOnDestroy() {
    console.log("===========CityComponent destroyed===============");
  }
  
  ngOnChanges() {
    console.log("===========CountryComponent ngOnChanges===============");
  }
  
  ngAfterContentInit() {
    console.log("===========CityComponent ngAfterContentInit===============");
  }
  
  ngAfterContentChecked() {
    console.log("===========CityComponent ngAfterContentChecked===============");
  }
  
  ngAfterViewChecked() {
    console.log("===========CityComponent ngAfterViewChecked===============");
  }
  
  ngAfterViewInit() {
    console.log("===========CityComponent ngAfterViewInit===============");
  }


}
