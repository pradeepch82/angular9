import { Directive } from '@angular/core';

@Directive({
  selector: '[appShow]'
})
export class ShowDirective {

  constructor() { }

}
