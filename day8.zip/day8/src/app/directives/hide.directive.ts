import { Directive } from '@angular/core';

@Directive({
  selector: '[appHide]'
})
export class HideDirective {

  constructor() { }

}
